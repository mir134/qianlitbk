﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("NSoup")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("NSoup")]
[assembly: AssemblyCopyright("Copyright ©  2012 Amir Grozki")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("ea7c4382-d4cf-470b-9525-72d42850c656")]

// Added by popular demand.
[assembly: System.Security.AllowPartiallyTrustedCallers]

[assembly: InternalsVisibleTo("Test, PublicKey=0024000004800000940000000602000000240000525341310004000001000100ff2769904d9601c999569e2ebea98b0822f0c58cb1a59d26ac1b3f0a9361cc58217d8c119b0cd0b8b16cb74e470f1b3c50334cefee49b3a0f9ca5830f418584c7ae8f9860a5fe91cdc2a51e8db16d8d1575c053c2e24bca46f644dcf12b3633829077a0ff5e68e4ca0491b9fbba3b19a06eb2887251bcb186486e2d2ddcbb3b5")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("0.8.0.0")]
[assembly: AssemblyFileVersion("0.8.0.0")]
